import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ICompany } from '../../../../../../../models/simple.schema';
import { CompanyFinancialsService, ICompanyFinancials } from '../../../../../../../services/company-financials.service';
import { HttpClient } from '@angular/common/http';
import { PdfExportService } from '../../../../../../../services/pdf-export.service';

@Component({
  selector: 'app-financial-checkin-overview',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="bg-white rounded-lg shadow-sm border border-gray-200">
      <!-- Header -->
      <div class="px-6 py-4 border-b border-gray-200 bg-gray-50">
        <div class="flex justify-between items-center">
          <div>
            <h3 class="text-lg font-semibold text-gray-900">Bank Statement</h3>
            <p class="text-sm text-gray-600 mt-1">Monthly turnover tracking</p>
          </div>

          <!-- Year Selector -->
          <div class="flex items-center gap-4">
            <div class="flex items-center gap-2">
              <label class="text-sm font-medium text-gray-700">Year:</label>
              <select
                [(ngModel)]="selectedYear"
                (change)="onYearChange()"
                class="px-3 py-1 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                <option value="all">All Years</option>
                <option *ngFor="let year of availableYears" [value]="year">{{ year }}</option>
              </select>
            </div>

            <div class="flex gap-2">
              <button
                (click)="exportBankStatement()"
                [disabled]="isExporting || monthlyRecords.length === 0"
                class="px-4 py-2 bg-green-600 text-white text-sm font-medium rounded hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center">
                <i *ngIf="!isExporting" class="fas fa-file-invoice-dollar mr-2"></i>
                <svg *ngIf="isExporting" class="animate-spin w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24">
                  <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                  <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                {{ isExporting ? 'Exporting...' : 'Export Bank Statement' }}
              </button>
              <button
                (click)="addNewMonth()"
                class="px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded hover:bg-blue-700 transition-colors">
                Add Month
              </button>
              <button
                (click)="onViewTrends()"
                class="px-4 py-2 bg-gray-600 text-white text-sm font-medium rounded hover:bg-gray-700 transition-colors">
                View Trends
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- Add New Record Modal -->
      <div *ngIf="showAddForm" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div class="bg-white rounded-lg shadow-xl max-w-md w-full mx-4">
          <div class="px-6 py-4 border-b border-gray-200">
            <h4 class="text-lg font-semibold text-gray-900">Add New Monthly Record</h4>
          </div>

          <div class="px-6 py-4">
            <div class="space-y-4">
              <!-- Year Selection -->
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Year</label>
                <select
                  [(ngModel)]="newRecordForm.year"
                  class="w-full px-3 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                  <option [value]="year" *ngFor="let year of [2020, 2021, 2022, 2023, 2024, 2025, 2026, 2027, 2028, 2029, 2030]">{{ year }}</option>
                </select>
              </div>

              <!-- Month Selection -->
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Month</label>
                <select
                  [(ngModel)]="newRecordForm.month"
                  (change)="onNewRecordMonthChange()"
                  class="w-full px-3 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                  <option [value]="1">January</option>
                  <option [value]="2">February</option>
                  <option [value]="3">March</option>
                  <option [value]="4">April</option>
                  <option [value]="5">May</option>
                  <option [value]="6">June</option>
                  <option [value]="7">July</option>
                  <option [value]="8">August</option>
                  <option [value]="9">September</option>
                  <option [value]="10">October</option>
                  <option [value]="11">November</option>
                  <option [value]="12">December</option>
                </select>
              </div>

              <!-- Quarter (auto-calculated) -->
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Quarter</label>
                <input
                  [value]="'Q' + newRecordForm.quarter"
                  readonly
                  class="w-full px-3 py-2 border border-gray-300 rounded bg-gray-50 text-gray-500">
              </div>

              <!-- Turnover -->
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Turnover (Optional)</label>
                <input
                  type="number"
                  [(ngModel)]="newRecordForm.turnover"
                  class="w-full px-3 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="0.00"
                  step="0.01">
              </div>
            </div>
          </div>

          <div class="px-6 py-4 border-t border-gray-200 flex justify-end gap-3">
            <button
              (click)="cancelAddForm()"
              class="px-4 py-2 text-gray-700 border border-gray-300 rounded hover:bg-gray-50 transition-colors">
              Cancel
            </button>
            <button
              (click)="saveNewRecord()"
              class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors">
              Add Record
            </button>
          </div>
        </div>
      </div>

      <!-- Financial Data Table -->
      <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200">
          <thead class="bg-gray-50">
            <tr>
              <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                {{ selectedYear === 'all' ? 'Period' : 'Month' }}
              </th>
              <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Quarter</th>
              <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Turnover</th>
              <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody class="bg-white divide-y divide-gray-200">
            <tr *ngFor="let record of monthlyRecords; trackBy: trackByRecord">
              <!-- Month/Period -->
              <td class="px-6 py-4 whitespace-nowrap">
                <span class="text-sm font-medium text-gray-900">
                  {{ selectedYear === 'all' ? (getMonthName(record.month) + ' ' + record.year) : getMonthName(record.month) }}
                </span>
              </td>

              <!-- Quarter -->
              <td class="px-6 py-4 whitespace-nowrap">
                <select
                  [(ngModel)]="record.quarter"
                  (change)="updateQuarter(record)"
                  class="px-3 py-2 text-sm border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                  <option value="1">Q1</option>
                  <option value="2">Q2</option>
                  <option value="3">Q3</option>
                  <option value="4">Q4</option>
                </select>
              </td>

              <!-- Turnover -->
              <td class="px-6 py-4 whitespace-nowrap">
                <input
                  type="number"
                  [(ngModel)]="record.turnover"
                  (blur)="updateRecord(record)"
                  class="w-32 px-3 py-2 text-sm border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="0.00"
                  step="0.01" />
              </td>

              <!-- Actions -->
              <td class="px-6 py-4 whitespace-nowrap text-sm">
                <button
                  (click)="deleteRecord(record)"
                  class="text-red-600 hover:text-red-900 transition-colors">
                  🗑️
                </button>
              </td>
            </tr>
          </tbody>

          <!-- Totals Row -->
          <tfoot *ngIf="monthlyRecords.length > 0" class="bg-gray-50 border-t-2 border-gray-300">
            <tr>
              <td class="px-6 py-3 text-sm font-bold text-gray-900">TOTAL</td>
              <td class="px-6 py-3 text-sm font-bold text-gray-900">-</td>
              <td class="px-6 py-3 text-sm font-bold text-gray-900">{{ formatCurrency(getTotalTurnover()) }}</td>
              <td class="px-6 py-3 text-sm font-bold text-gray-900">-</td>
            </tr>
          </tfoot>
        </table>
      </div>

      <!-- Empty State -->
      <div *ngIf="monthlyRecords.length === 0" class="px-6 py-12 text-center">
        <div class="text-gray-400 text-4xl mb-4">🏦</div>
        <h3 class="text-sm font-medium text-gray-900 mb-2">
          No Bank Statement Data{{ selectedYear === 'all' ? '' : ' for ' + selectedYear }}
        </h3>
        <p class="text-sm text-gray-500 mb-4">Start by adding your first monthly turnover record.</p>
        <button
          (click)="addNewMonth()"
          class="px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded hover:bg-blue-700 transition-colors">
          Add Monthly Turnover
        </button>
      </div>
    </div>
  `,
})
export class FinancialCheckinOverviewComponent implements OnInit {
  @Input() company!: ICompany;
  @Output() recordUpdated = new EventEmitter<ICompanyFinancials>();
  @Output() recordDeleted = new EventEmitter<number>();
  @Output() addMonthRequested = new EventEmitter<{ month: number; year: number }>();

  // Legacy events for compatibility with parent component
  @Output() onNewCheckInClick = new EventEmitter<void>();
  @Output() onViewTrendsClick = new EventEmitter<void>();
  @Output() onEditCheckIn = new EventEmitter<ICompanyFinancials>();

  financials: ICompanyFinancials[] = [];
  loading = false;
  error: string | null = null;

  selectedYear: string | number = 'all';

  readonly monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  // Export state
  isExporting = false;

  constructor(
    private financialService: CompanyFinancialsService,
    private http: HttpClient,
    private pdfExportService: PdfExportService
  ) {}

  ngOnInit() {
    this.loadFinancials();
  }

  get availableYears(): number[] {
    const years = new Set(this.financials.map(f => f.year));
    const yearArray = Array.from(years).sort((a, b) => b - a);

    // Ensure current year is always available
    const selectedYearNum = Number(this.selectedYear);
    if (!yearArray.includes(selectedYearNum)) {
      yearArray.unshift(selectedYearNum);
      yearArray.sort((a, b) => b - a);
    }

    return yearArray;
  }

  get monthlyRecords(): ICompanyFinancials[] {
    if (this.selectedYear === 'all') {
      // Return all records sorted by year (descending) then month (ascending)
      return this.financials
        .filter(f => f.id > 0) // Only show saved records
        .sort((a, b) => {
          if (a.year !== b.year) return b.year - a.year; // Sort years descending (newest first)
          return a.month - b.month; // Sort months ascending within each year
        });
    }

    // Get records for selected year, sorted by month
    const selectedYearNum = Number(this.selectedYear);
    return this.financials
      .filter(f => f.year === selectedYearNum && f.id > 0) // Only show saved records for the selected year
      .sort((a, b) => a.month - b.month);
  }

  trackByRecord(index: number, record: ICompanyFinancials): number {
    return record.id || index;
  }

  async loadFinancials() {
    if (!this.company?.id) {
      return;
    }

    this.loading = true;
    this.error = null;

    try {
      const data = await this.financialService
        .listAllCompanyFinancials(this.company.id)
        .toPromise();

      this.financials = data || [];

    } catch (error) {
      console.error('Error loading financials:', error);
      this.error = 'Failed to load financial data. Please try again.';
    } finally {
      this.loading = false;
    }
  }

  onYearChange() {
    // Year selector changed - data will be filtered automatically by monthlyRecords getter
  }

  getMonthName(month: number): string {
    return this.monthNames[month - 1] || 'Unknown';
  }

  getRecordsForSelectedYear(): number {
    if (this.selectedYear === 'all') {
      return this.financials.filter(f => Number(f.turnover) > 0).length;
    }
    const selectedYearNum = Number(this.selectedYear);
    return this.financials.filter(f => f.year === selectedYearNum).length;
  }

  async updateRecord(record: ICompanyFinancials): Promise<void> {
    // Only update existing records (id > 0)
    if (record.id === 0) {
      return;
    }

    // Set turnover_monthly_avg same as turnover for bank statement
    record.turnover_monthly_avg = record.turnover;

    try {
      await this.financialService.updateCompanyFinancials(record.id, record).toPromise();
      this.recordUpdated.emit(record);
    } catch (error) {
      console.error('Error updating record:', error);
      alert('Failed to save changes. Please try again.');
    }
  }

  async updateQuarter(record: ICompanyFinancials): Promise<void> {
    // Only update existing records (id > 0)
    if (record.id === 0) {
      return;
    }

    // Update the quarter_label based on the selected quarter
    record.quarter_label = `Q${record.quarter}`;

    try {
      await this.financialService.updateCompanyFinancials(record.id, record).toPromise();
      this.recordUpdated.emit(record);
    } catch (error) {
      console.error('Error updating quarter:', error);
      alert('Failed to save quarter changes. Please try again.');
    }
  }

  async deleteRecord(record: ICompanyFinancials): Promise<void> {
    if (record.id === 0) {
      // This shouldn't happen with the new logic, but just in case
      return;
    }

    if (confirm(`Delete ${this.getMonthName(record.month)} ${record.year} data?`)) {
      try {
        await this.financialService.deleteCompanyFinancials(record.id).toPromise();
        this.recordDeleted.emit(record.id);
        this.loadFinancials();
      } catch (error) {
        console.error('Error deleting record:', error);
        alert('Failed to delete record. Please try again.');
      }
    }
  }

  // Add new record form state
  showAddForm = false;
  newRecordForm = {
    month: new Date().getMonth() + 1,
    year: new Date().getFullYear(),
    quarter: Math.ceil((new Date().getMonth() + 1) / 3),
    turnover: null as number | null
  };

  addNewMonth(): void {
    // Reset form with current date defaults
    this.newRecordForm = {
      month: new Date().getMonth() + 1,
      year: new Date().getFullYear(),
      quarter: Math.ceil((new Date().getMonth() + 1) / 3),
      turnover: null
    };
    this.showAddForm = true;
  }

  onNewRecordMonthChange(): void {
    // Update quarter when month changes
    this.newRecordForm.quarter = Math.ceil(this.newRecordForm.month / 3);
  }

  cancelAddForm(): void {
    this.showAddForm = false;
  }

  async saveNewRecord(): Promise<void> {
    // Validate form
    if (!this.newRecordForm.month || !this.newRecordForm.year) {
      alert('Please select a month and year.');
      return;
    }

    // Check if record already exists for this month/year
    const existingRecord = this.financials.find(f =>
      f.month === this.newRecordForm.month &&
      f.year === this.newRecordForm.year
    );

    if (existingRecord) {
      alert(`A record for ${this.getMonthName(this.newRecordForm.month)} ${this.newRecordForm.year} already exists.`);
      return;
    }

    // Create new record
    const newRecord: ICompanyFinancials = {
      id: 0,
      company_id: this.company.id,
      period_date: `${this.newRecordForm.year}-${this.newRecordForm.month.toString().padStart(2, '0')}-01`,
      year: this.newRecordForm.year,
      month: this.newRecordForm.month,
      quarter: this.newRecordForm.quarter,
      quarter_label: `Q${this.newRecordForm.quarter}`,
      is_pre_ignition: false,
      turnover_monthly_avg: this.newRecordForm.turnover,
      turnover: this.newRecordForm.turnover,
      cost_of_sales: null,
      business_expenses: null,
      gross_profit: null,
      net_profit: null,
      gp_margin: null,
      np_margin: null,
      cash_on_hand: null,
      debtors: null,
      creditors: null,
      inventory_on_hand: null,
      working_capital_ratio: null,
      net_assets: null,
      notes: null,
      created_at: '',
      updated_at: ''
    };

    try {
      const savedRecord = await this.financialService.addCompanyFinancials(newRecord).toPromise();
      if (savedRecord) {
        this.showAddForm = false;
        this.loadFinancials();

        // Switch to the year of the new record if not already viewing it
        if (this.selectedYear !== this.newRecordForm.year && this.selectedYear !== 'all') {
          this.selectedYear = this.newRecordForm.year;
        }
      }
    } catch (error) {
      console.error('Error creating new record:', error);
      alert('Failed to create new record. Please try again.');
    }
  }

  // Total calculation method
  getTotalTurnover(): number {
    return this.monthlyRecords.reduce((sum, r) => {
      const turnover = Number(r.turnover) || 0;
      return sum + turnover;
    }, 0);
  }

  formatCurrency(value: number): string {
    if (isNaN(value) || value === 0) return '-';
    return new Intl.NumberFormat('en-ZA', {
      style: 'currency',
      currency: 'ZAR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(value);
  }

  // Public method to refresh data from parent component
  public refreshData() {
    this.loadFinancials();
  }

  // Legacy methods for compatibility with parent component
  onNewCheckIn() {
    this.onNewCheckInClick.emit();
  }

  onViewTrends() {
    this.onViewTrendsClick.emit();
  }

  // Since we have inline editing, we don't really "edit" records anymore
  // But if needed, this could emit when clicking on a record
  onEditRecord(record: ICompanyFinancials) {
    this.onEditCheckIn.emit(record);
  }

  /**
   * Export bank statement as PDF
   */
  exportBankStatement(): void {
    if (this.isExporting || this.monthlyRecords.length === 0) return;

    this.isExporting = true;

    // Filter records with actual data
    const validRecords = this.monthlyRecords.filter(record =>
      record.id > 0 && (record.turnover !== null && Number(record.turnover) > 0)
    );

    // Generate HTML using the service
    const html = this.pdfExportService.generateBankStatementHtml(this.company, validRecords);

    // Send to PDF service
    const formData = new FormData();
    formData.append('html', html);
    formData.append('options', JSON.stringify({
      format: 'A4',
      margin: { top: '0.5cm', right: '1cm', bottom: '0.5cm', left: '1cm' },
      printBackground: true,
      preferCSSPageSize: true
    }));

    this.http.post('https://docs.tybo.co.za/pdf.php', formData, {
      responseType: 'blob'
    }).subscribe({
      next: (blob: Blob) => {
        // Download the PDF
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        const filename = `${this.company.name.replace(/[^a-zA-Z0-9]/g, '_')}_Bank_Statement_${new Date().toISOString().split('T')[0]}.pdf`;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);

        console.log('Bank statement export completed successfully');
        this.isExporting = false;
      },
      error: (error: any) => {
        console.error('Export failed:', error);
        alert('Export failed. Please try again.');
        this.isExporting = false;
      }
    });
  }

}
