export const Constants = {
  Currency: 'ZAR', // Fixed: Use proper ISO currency code for South African Rand
  LocalUser: 'currentUser',
  // ApiBase: 'http://localhost:8080',
  ApiBase: 'https://app.rbttacesd.co.za/api/',
};
